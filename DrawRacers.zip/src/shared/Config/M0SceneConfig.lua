--!strict

-- M0 physics-lab scene contract.
-- Coordinates follow the production convention: +X travel, Y up, Z lane center.
-- The five canonical B15 pieces use doc 60 defaults with 10-stud recovery spacing.

return {
	SceneName = "M0TestScene",
	Lane = {
		Length = 180,
		Width = 8,
		Thickness = 2,
		TopY = 0,
	},
	Spawn = {
		X = 4,
		Y = 3,
		Z = 0,
	},
	-- G0-only presentation/recovery containment. CameraMinFollowY never changes racer physics;
	-- RecoveryKillY only controls the Studio human-harness reset boundary.
	CameraMinFollowY = 0,
	RecoveryKillY = -6,
	ReferenceBenchmark = {
		Name = "R16FlatBenchmark",
		StartX = 0,
		Length = 60,
		CenterZ = 16,
		TopY = 0,
		Width = 8,
		Thickness = 2,
		SpawnX = 4,
		SpawnY = 3.3,
	},
	ReferenceAcceptance = {
		TrackContactTimeout = 4.0,
		FlatIgnoreSeconds = 2.0,
		FlatMeasureSeconds = 3.0,
		FlatSpeedMin = 4.0,
		FlatSpeedMax = 7.0,
		StepsMeasureSeconds = 10.0,
		StepsRiseMin = 0.25,
		StepsProgressAdvantage = 4.0,
		GapMeasureSeconds = 6.0,
		GapFallMin = 1.0,
		GapProgressAdvantage = 2.0,
		TunnelMeasureSeconds = 8.0,
		TunnelProgressAdvantage = 6.0,
		SuboptimalWorseRatio = 0.20,
		WallContactTimeout = 8.0,
		WallMeasureSeconds = 8.0,
		MovingRedrawSettleSeconds = 0.5,
		MovingRedrawStepSeconds = 0.25,
		MovingRedrawMinProgress = 0.5,
	},
	Pieces = {
		{
			AnchorName = "FlatAnchor",
			PieceId = "FlatShort",
			StartX = 10,
			Length = 18,
		},
		{
			AnchorName = "StepsAnchor",
			PieceId = "SmallSteps",
			StartX = 38,
			Length = 28,
			Height = 1.5,
			Depth = 4.0,
			Gap = 1.0,
			Count = 5,
		},
		{
			AnchorName = "WallAnchor",
			PieceId = "SingleWallLow",
			StartX = 76,
			Length = 20,
			Height = 2.6,
			Thickness = 2.0,
		},
		{
			AnchorName = "GapAnchor",
			PieceId = "GapSmall",
			StartX = 106,
			Length = 24,
			GapWidth = 3.2,
		},
		{
			AnchorName = "TunnelAnchor",
			PieceId = "LowTunnelWide",
			StartX = 140,
			Length = 28,
			Clearance = 4.25,
			TunnelLength = 16,
			CeilingThickness = 2,
		},
	},
}
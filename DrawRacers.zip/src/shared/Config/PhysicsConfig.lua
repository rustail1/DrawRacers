--!strict

return {
	StrokeProcessing = {
		RawSampleMinMovementNormalized = 0.010,
		MaxRawPoints = 96,
		MinimumRawPoints = 3,
		DedupeDistance = 0.012,
		RDPEpsilon = 0.022,
		ResampleTargetPoints = 12,
		MaxCleanedPoints = 15,
		MinimumCleanedPolylineLength = 0.18,
		RawSemanticHalfWidth = 1.75,
		RawSemanticHalfHeight = 1.0,
		NormalizedMin = -1,
		NormalizedMax = 1,
		StrokeSubmitCooldown = 0.20,
		MaxStrokePayloadBytes = 4096,
		StrokeResultTimeout = 3.0,
		MaxPendingStrokes = 4,
	},

	LegGeometry = {
		LegCanvasHalfSpan = 3.2,
		MaxLegExtentFromHub = 4.5,
		MinUsefulLegExtent = 0.7,

		-- Shared Z-axis axle; roots live outside the two cube side faces.
		LegMountOutset = 0.45,
		LegMountVerticalFraction = 0.0,
		RightLegFixedPhaseDegrees = 180,

		PhysicalLegSegmentThickness = 0.54,
		VisualLegSegmentThickness = 0.78,
		MaxColliderSegmentsPerLeg = 14,
		InnerHubNoCollisionRadius = 0.65,
		MinimumMappedSegmentLength = 0.08,
		SegmentOverlapAllowance = 0.06,
	},

	LegReshape = {
		-- RacerRuntime still uses these values to time its redraw transaction.
		-- LegPairAssembly independently renders the preview every Heartbeat.
		TypicalDuration = 0.085,
		MinimumDuration = 0.075,
		MaximumDuration = 0.095,
	},

	BodyDynamics = {
		-- Reference-like: very light response and strongly reduced effective gravity.
		GravityScale = 0.28,
		RedrawHopTargetVelocity = 4.5,
		RedrawHopMaxDeltaVelocity = 6.5,
	},

	Motor = {
		RotationSign = -1,
		TargetTipSpeed = 15.0,
		MinimumDriveRadius = 1.75,
		MinAngularVelocity = 1.5,
		MaxAngularVelocity = 8.0,
		MotorMaxTorque = 35000,
		MotorMaxAcceleration = 120,
	},

	ColliderActivation = {
		-- Final leg colliders are born disabled. A collider is enabled only after
		-- this shrunken probe no longer intersects collidable Track geometry.
		ActivationProbeInset = 0.08,
		MinimumProbeSize = 0.05,
		MaxProbeParts = 32,
	},

	PhysicalMaterials = {
		Body = {
			Density = 0.25,
			Friction = 0.40,
			Elasticity = 0.04,
			FrictionWeight = 100,
			ElasticityWeight = 100,
		},
		LegSegment = {
			Density = 0.60,
			Friction = 1.0,
			Elasticity = 0.02,
			FrictionWeight = 100,
			ElasticityWeight = 100,
		},
		Axle = {
			Density = 0.05,
			Friction = 0.0,
			Elasticity = 0.0,
			FrictionWeight = 0,
			ElasticityWeight = 0,
		},
	},

	Stabilization = {
		LaneNormalError = 0.03,
		LaneHardBound = 0.08,
		OrientationResponsiveness = 40,
		OrientationMaxTorque = 60000,
		OrientationMaxAngularVelocity = 30,
	},

	AntiStall = {
		Enabled = true,
		ActivationForwardSpeed = 0.35,
		ActivationDelay = 0.60,
		MaxAccelerationX = 2.0,
		MaxAssistDuration = 0.75,
		DisableForwardSpeed = 1.0,
	},

	Recovery = {
		ProgressSampleWindow = 2.5,
		MeaningfulHorizontalProgress = 0.35,
	},
}

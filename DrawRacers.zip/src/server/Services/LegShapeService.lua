--!strict

local HttpService = game:GetService("HttpService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local PhysicsConfig = require(
	ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Config"):WaitForChild("PhysicsConfig")
)
local CanonicalLegShape = require(
	ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Math"):WaitForChild("CanonicalLegShape")
)
local StrokeTypes = require(
	ReplicatedStorage:WaitForChild("Shared"):WaitForChild("Types"):WaitForChild("StrokeTypes")
)

local LegShapeService = {}

type SemanticPoints = StrokeTypes.SemanticPoints
type ShapeSpec = StrokeTypes.ShapeSpec
type LegShapeResult = StrokeTypes.LegShapeResult
type StrokeResultPayload = StrokeTypes.StrokeResultPayload

local function isFiniteNumber(value: number): boolean
	return value == value and value ~= math.huge and value ~= -math.huge
end

local function reject(reasonCode: string, clearAccepted: boolean?): LegShapeResult
	return {
		accepted = false,
		rejectReasonCode = reasonCode,
		clearAccepted = if clearAccepted == true then true else nil,
	}
end

local function networkReject(sequence: number, reasonCode: string, clearAccepted: boolean?): StrokeResultPayload
	return {
		sequence = sequence,
		accepted = false,
		rejectReasonCode = reasonCode,
		clearAccepted = if clearAccepted == true then true else nil,
	}
end

local function serializeSemanticPoints(points: { Vector2 }): SemanticPoints
	local result = table.create(#points)
	for index, point in points do result[index] = { x = point.X, y = point.Y } end
	return result
end

local function validateRawPointArray(rawPoints: any): ({ Vector2 }?, string?)
	local config = PhysicsConfig.StrokeProcessing
	if type(rawPoints) ~= "table" then return nil, "MALFORMED_POINTS" end
	local entryCount = 0
	local maxIndex = 0
	for key, _ in rawPoints do
		if type(key) ~= "number" or key < 1 or math.floor(key) ~= key then return nil, "MALFORMED_POINTS" end
		entryCount += 1
		if entryCount > config.MaxRawPoints or key > config.MaxRawPoints then return nil, "TOO_MANY_POINTS" end
		maxIndex = math.max(maxIndex, key)
	end
	if entryCount < config.MinimumRawPoints then return nil, "TOO_FEW_POINTS" end
	if maxIndex ~= entryCount then return nil, "MALFORMED_POINTS" end
	local points = table.create(entryCount)
	for index = 1, entryCount do
		local point = rawPoints[index]
		if typeof(point) ~= "Vector2" then return nil, "MALFORMED_POINTS" end
		points[index] = point
	end
	return points, nil
end

local function buildDebugId(version: number, points: { Vector2 }, length: number): string
	local first = points[1]
	local last = points[#points]
	return string.format("shape-v%d-p%d-l%.4f-f%.3f,%.3f-z%.3f,%.3f", version, #points, length, first.X, first.Y, last.X, last.Y)
end

function LegShapeService.ValidateAndBuild(racerRuntime: any, rawPoints: any, motorEnabled: boolean?): LegShapeResult
	if type(racerRuntime) ~= "table"
		or type(racerRuntime.GetShapeVersion) ~= "function"
		or type(racerRuntime.ApplyValidatedShape) ~= "function"
	then
		return reject("INVALID_RACER")
	end

	local points, arrayError = validateRawPointArray(rawPoints)
	if points == nil then return reject(arrayError or "MALFORMED_POINTS") end
	local canonical, canonicalError = CanonicalLegShape.Build(points, PhysicsConfig.StrokeProcessing, PhysicsConfig.LegGeometry)
	if canonical == nil then return reject(canonicalError or "INVALID_STROKE") end

	local nextVersion = racerRuntime:GetShapeVersion() + 1
	local shapeSpec: ShapeSpec = {
		version = nextVersion,
		normalizedPoints = canonical.normalizedPoints,
		mappedPoints = canonical.mappedPoints,
		bounds = canonical.bounds,
		extent = canonical.extent,
		segmentPlan = canonical.segmentPlan,
		debugRawPointCount = canonical.debugRawPointCount,
		debugPhysicsPointCount = canonical.debugPhysicsPointCount,
		debugId = buildDebugId(nextVersion, canonical.normalizedPoints, canonical.cleanedLength),
	}

	local callOk, applyResult = pcall(function()
		return racerRuntime:ApplyValidatedShape(shapeSpec, motorEnabled)
	end)
	if not callOk then
		warn(string.format("[DrawRacers][LegShapeService] validated shape application failed: %s", tostring(applyResult)))
		return reject("BUILD_FAILED")
	end
	if type(applyResult) ~= "table" or applyResult.accepted ~= true then
		local reason = if type(applyResult) == "table" and type(applyResult.rejectReasonCode) == "string"
			then applyResult.rejectReasonCode
			else "BUILD_FAILED"
		local clearAccepted = type(applyResult) == "table" and applyResult.clearAccepted == true
		return reject(reason, clearAccepted)
	end

	return { accepted = true, shapeVersion = nextVersion, shapeSpec = shapeSpec }
end

local function extractSequence(payload: any): number?
	if type(payload) ~= "table" then return nil end
	local sequence = payload.sequence
	if type(sequence) ~= "number" or not isFiniteNumber(sequence) or sequence < 1 or math.floor(sequence) ~= sequence then
		return nil
	end
	return sequence
end

function LegShapeService.ExtractSafeSequence(payload: any): number?
	return extractSequence(payload)
end

local function validateNetworkEnvelope(payload: any): string?
	if type(payload) ~= "table" then return "MALFORMED_PAYLOAD" end
	local fieldCount = 0
	for key, _ in payload do
		fieldCount += 1
		if fieldCount > 2 or (key ~= "sequence" and key ~= "points") then return "MALFORMED_PAYLOAD" end
	end
	if fieldCount ~= 2 or payload.points == nil then return "MALFORMED_PAYLOAD" end
	return nil
end

local function validateSemanticPoint(point: any): (number?, number?, string?)
	if type(point) ~= "table" then return nil, nil, "MALFORMED_POINTS" end
	local fieldCount = 0
	for key, _ in point do
		fieldCount += 1
		if fieldCount > 2 or (key ~= "x" and key ~= "y") then return nil, nil, "MALFORMED_POINTS" end
	end
	if fieldCount ~= 2 then return nil, nil, "MALFORMED_POINTS" end
	local x = point.x
	local y = point.y
	if type(x) ~= "number" or type(y) ~= "number" then return nil, nil, "MALFORMED_POINTS" end
	if not isFiniteNumber(x) or not isFiniteNumber(y) then return nil, nil, "NON_FINITE_POINT" end
	return x, y, nil
end

local function validateNetworkPoints(rawPoints: any): ({ Vector2 }?, SemanticPoints?, string?)
	local config = PhysicsConfig.StrokeProcessing
	if type(rawPoints) ~= "table" then return nil, nil, "MALFORMED_POINTS" end
	local entryCount = 0
	local maxIndex = 0
	for key, _ in rawPoints do
		if type(key) ~= "number" or key < 1 or math.floor(key) ~= key then return nil, nil, "MALFORMED_POINTS" end
		entryCount += 1
		if entryCount > config.MaxRawPoints or key > config.MaxRawPoints then return nil, nil, "TOO_MANY_POINTS" end
		maxIndex = math.max(maxIndex, key)
	end
	if entryCount < config.MinimumRawPoints then return nil, nil, "TOO_FEW_POINTS" end
	if maxIndex ~= entryCount then return nil, nil, "MALFORMED_POINTS" end

	local vectors = table.create(entryCount)
	local canonicalPoints: SemanticPoints = table.create(entryCount)
	for index = 1, entryCount do
		local x, y, pointError = validateSemanticPoint(rawPoints[index])
		if pointError ~= nil or x == nil or y == nil then return nil, nil, pointError or "MALFORMED_POINTS" end
		vectors[index] = Vector2.new(x, y)
		canonicalPoints[index] = { x = x, y = y }
	end
	return vectors, canonicalPoints, nil
end

function LegShapeService.CreateSubmitProcessor(deps: any)
	assert(type(deps) == "table", "CreateSubmitProcessor requires deps")
	assert(type(deps.resolveRacer) == "function", "CreateSubmitProcessor requires resolveRacer")
	local nowFn = deps.now or os.clock
	assert(type(nowFn) == "function", "CreateSubmitProcessor now must be a function")
	local states = setmetatable({}, { __mode = "k" })
	local processor = {}

	function processor:Handle(playerKey: any, payload: any): StrokeResultPayload?
		local sequence = extractSequence(payload)
		if sequence == nil then return nil end
		local envelopeError = validateNetworkEnvelope(payload)
		if envelopeError ~= nil then return networkReject(sequence, envelopeError) end
		local racerRuntime = deps.resolveRacer(playerKey)
		if racerRuntime == nil then return networkReject(sequence, "NO_RACER") end

		local state = states[playerKey]
		if state == nil then
			state = { lastAcceptedSequence = 0, pendingSequence = nil, lastRequestAt = -math.huge, mechanicalPending = false }
			states[playerKey] = state
		end
		if state.mechanicalPending == true then
			return networkReject(sequence, "REDRAW_PENDING")
		end
		local pendingSequence = state.pendingSequence
		if sequence <= state.lastAcceptedSequence or (pendingSequence ~= nil and sequence <= pendingSequence) then
			return networkReject(sequence, "STALE_SEQUENCE")
		end
		state.pendingSequence = sequence

		local now = nowFn()
		if type(now) ~= "number" or not isFiniteNumber(now) then
			state.pendingSequence = nil
			return networkReject(sequence, "SERVER_TIME_INVALID")
		end
		if now - state.lastRequestAt < PhysicsConfig.StrokeProcessing.StrokeSubmitCooldown then
			state.pendingSequence = nil
			return networkReject(sequence, "RATE_LIMITED")
		end
		state.lastRequestAt = now

		local vectors, canonicalPoints, pointsError = validateNetworkPoints(payload.points)
		if vectors == nil or canonicalPoints == nil then
			state.pendingSequence = nil
			return networkReject(sequence, pointsError or "MALFORMED_POINTS")
		end
		local encodedOk, encodedPayload = pcall(function()
			return HttpService:JSONEncode({ sequence = sequence, points = canonicalPoints })
		end)
		if not encodedOk or type(encodedPayload) ~= "string" then
			state.pendingSequence = nil
			return networkReject(sequence, "MALFORMED_POINTS")
		end
		if #encodedPayload > PhysicsConfig.StrokeProcessing.MaxStrokePayloadBytes then
			state.pendingSequence = nil
			return networkReject(sequence, "PAYLOAD_TOO_LARGE")
		end

		-- mechanicalPending is a server-side transaction lock. Clear it on every
		-- exit path, including unexpected exceptions before ApplyValidatedShape can
		-- convert the failure into a normal mechanical reject. Otherwise one bad
		-- request can poison the player forever with REDRAW_PENDING.
		state.mechanicalPending = true
		local buildOk, buildResultOrError = xpcall(function()
			return LegShapeService.ValidateAndBuild(racerRuntime, vectors, true)
		end, debug.traceback)
		state.mechanicalPending = false
		state.pendingSequence = nil

		if not buildOk then
			warn(string.format(
				"[DrawRacers][LegShapeService] mechanical transaction failed: %s",
				tostring(buildResultOrError)
			))
			return networkReject(sequence, "MECHANICAL_INTERNAL_ERROR")
		end

		local buildResult = buildResultOrError
		if type(buildResult) ~= "table" then
			return networkReject(sequence, "MECHANICAL_INTERNAL_ERROR")
		end
		if buildResult.accepted == true then
			state.lastAcceptedSequence = sequence
			local shapeSpec = buildResult.shapeSpec
			assert(shapeSpec ~= nil, "accepted build missing ShapeSpec")
			return {
				sequence = sequence,
				accepted = true,
				shapeVersion = buildResult.shapeVersion,
				acceptedPoints = serializeSemanticPoints(shapeSpec.normalizedPoints),
			}
		end
		return networkReject(
			sequence,
			buildResult.rejectReasonCode or "INVALID_STROKE",
			buildResult.clearAccepted == true
		)
	end
	return processor
end

return LegShapeService

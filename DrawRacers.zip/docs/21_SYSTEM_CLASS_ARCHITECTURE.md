# 21 — SYSTEM & CLASS ARCHITECTURE

Статус: **IMPLEMENTATION CONTRACT v1.3.5 / R17 OVERRIDE**  
Цель: заранее определить владельцев состояния, границы модулей и зависимости, чтобы Codex не создавал дублирующую архитектуру.

> В Luau не нужно превращать всё в OOP. Здесь слово «класс» означает stateful runtime object там, где lifetime действительно полезен. Stateless вычисления остаются обычными ModuleScript-функциями.

R17 Product Owner override is canonical for current M0 reference work. Presentation owners `CameraMath` / `RaceCameraController` and `RiderPresentationController` are active provisional M0 owners under `DECISION_LOG_R17_REFERENCE_CORE_OVERRIDE_2026-09-11.md`; the mechanical reference-fidelity override under `DECISION_LOG_R17_SHARED_AXLE_CAMERA_FIDELITY_2026-09-11.md` makes `LegPairAssembly` the production owner of one shared axle, one `AxleJoint` motor and the structural 180° relation between the two rigid side `LegAssembly` children. D09 and E03 are later multiplayer/readability extension-and-acceptance tasks for the existing presentation owners, not their first introduction. These bounded R17 exceptions do **not** authorize unrelated later modules: in particular `RacerService` remains D05 and C01+ remains sequence-gated.

---

# 1. DataModel target tree

The tree below is **TARGET architecture** for the ordered production route. It **does not authorize early implementation** of modules before their task/milestone becomes active in `25/66`, except for the explicit bounded R17 overrides above. In particular, **RacerService remains D05**. M0/B17 uses the existing **Studio-only injected resolver** in `M0HumanHarness`; **Do not implement RacerService before D05**.

```text
ReplicatedStorage
├── Shared
│   ├── Config
│   │   ├── PhysicsConfig.lua
│   │   ├── RaceConfig.lua
│   │   ├── TrackConfig.lua
│   │   ├── EconomyConfig.lua
│   │   ├── MonetizationConfig.lua
│   │   ├── BotConfig.lua
│   │   ├── PlaceConfig.lua
│   │   └── FeatureFlags.lua
│   ├── Types
│   │   ├── StrokeTypes.lua
│   │   ├── RaceTypes.lua
│   │   ├── TrackTypes.lua
│   │   └── ProfileTypes.lua
│   ├── Math
│   │   ├── StrokeMath.lua
│   │   ├── GeometryMath.lua
│   │   ├── CameraMath.lua
│   │   └── TrackMath.lua
│   └── Net
│       └── RemoteNames.lua
├── Remotes
│   ├── SubmitStroke
│   ├── StrokeResult
│   ├── RaceEvent
│   ├── RequeueRequest
│   ├── CosmeticRequest
│   ├── CosmeticResult
│   ├── CatalogPurchaseRequest
│   ├── CatalogPurchaseResult
│   ├── SettingsRequest
│   ├── SettingsResult
│   ├── OfferRequest
│   ├── OfferResult
│   └── ProfileEvent
└── Assets
    └── CosmeticDefinitions

ServerStorage
├── RacerTemplates
└── TrackPieces

ServerScriptService
├── Bootstrap.server.lua
├── Services
│   ├── RaceService.lua
│   ├── RacerService.lua
│   ├── LegShapeService.lua
│   ├── TrackService.lua
│   ├── ProgressValidationService.lua
│   ├── PlayerDataService.lua
│   ├── RewardService.lua
│   ├── CosmeticService.lua
│   ├── MonetizationService.lua
│   ├── PlaceRouterService.lua
│   └── AnalyticsAdapter.lua
├── Runtime
│   ├── RaceRuntime.lua
│   ├── RacerRuntime.lua
│   ├── LegPairAssembly.lua
│   ├── LegAssembly.lua
│   ├── TrackRuntime.lua
│   ├── CheckpointTracker.lua
│   └── BotRacerController.lua
└── Tests

StarterPlayer
└── StarterPlayerScripts
    ├── Bootstrap.client.lua
    └── Controllers
        ├── InputController.lua
        ├── DrawingController.lua
        ├── RaceCameraController.lua
        ├── RiderPresentationController.lua
        ├── HUDController.lua
        ├── ResultsController.lua
        ├── GarageController.lua
        ├── StoreController.lua
        ├── SettingsController.lua
        ├── AudioController.lua
        └── FeedbackController.lua

StarterGui
├── RaceHUD
├── DrawHUD
├── ResultsHUD
├── GarageHUD
├── StoreHUD
└── SettingsHUD

Workspace
└── Runtime
    ├── Tracks
    ├── Racers
    └── RacePresentation
```

Folder names may change only by explicit architecture decision. Responsibilities below are the contract. Exact Studio Instance classes/properties/tags/collision matrix are owned by `65_STUDIO_DATAMODEL_INSTANCE_PROPERTY_SPEC.md`; UI child hierarchy is `68`.

---

# 2. Server boot order

`Bootstrap.server.lua` является composition root. Именно он создаёт/инициализирует project services и передаёт зависимости.

Recommended order once each ordered module is actually authorized/implemented:
1. `AnalyticsAdapter`
2. `PlayerDataService`
3. `TrackService`
4. `LegShapeService`
5. `RacerService`
6. `ProgressValidationService`
7. `RewardService`
8. `CosmeticService`
9. `MonetizationService`
10. `PlaceRouterService`
11. `RaceService`
12. route/start place-specific game loop

Причина: `RaceService` — orchestration layer, а не хозяин всех подсистем.

---

# 3. Server services

## RaceService
**Lifetime:** singleton/server.  
**Owns:** текущий phase heat, roster, current `RaceRuntime`, result transition/requeue orchestration **inside the current `PlaceMode`**. In `ENTRY_FTUE` it runs only the controlled T06 FTUE loop; in `RACE` it runs public rotation.  
**Does NOT own:** физическую сборку ног, persistent profile, TrackPiece models, reward formula details.

Public contract conceptually:
```text
Init(deps)
CreateHeat(playerList, trackDefinitionId)
StartCountdown()
StartRace()
HandlePlayerLeave(player)
RequestRequeue(player)
EndHeat(reason)
GetRaceForPlayer(player)
```

Depends on: `TrackService`, `RacerService`, `ProgressValidationService`, `RewardService`, `AnalyticsAdapter`.

---

## PlaceRouterService
**Lifetime:** singleton/server.  
**Owns:** place-mode validation and safe server-side routing between `EntryFTUEPlace` and `RacePlace` using the exact lifecycle in `41`.

Conceptual contract:
```text
Init(placeConfig, playerDataService)
RouteAfterProfileReady(player)
SendToRacePlace(player, reason)
SendToEntryFTUEPlace(player, reason)
GetPlaceMode() -> ENTRY_FTUE | RACE
```

Rules:
- only the server chooses destination after canonical profile state is known;
- `ENTRY_FTUE` never prompts paid products;
- teleport failure is retried with bounded backoff and visible non-destructive status; it never mutates tutorial/reward state to fake success;
- `RaceService` is started in the mode allowed by `PlaceConfig`, not as a second independent topology.

Depends on: `PlayerDataService`, Roblox TeleportService adapter, `AnalyticsAdapter`.

---

## RacerService
**First authorized task:** **D05** in the ordered implementation sequence. **RacerService remains D05** even though this target architecture document describes its future ownership now. M0/B17 must keep using the **Studio-only injected resolver** in `M0HumanHarness`. **Do not implement RacerService before D05**.

**Owns:** spawn/despawn racer entities and mapping `Player → RacerRuntime`.

```text
SpawnRacer(player, laneRuntime) -> RacerRuntime
GetRacer(player) -> RacerRuntime?
DespawnRacer(player)
ResetAll()
```

Does not process raw stroke math itself. For human racers, production spawn is also the server-authoritative source of the `OwnerUserId` presentation attribute defined by `65`; that identifier does not replace the internal Player→RacerRuntime mapping.

---

## LegShapeService
**Owns:** authoritative stroke validation and conversion `StrokePayload → ShapeSpec → LegPairAssembly`.

```text
ValidateAndBuild(player, racerRuntime, payload) -> Result
DestroyShape(shapeVersion)
```

Internally uses pure `StrokeMath`/`GeometryMath` and asks `RacerRuntime` to atomically replace the current shared `LegPairAssembly`. `LegAssembly` is only the rigid side-geometry constructor used by the pair; it is not an independent motor owner.

Does NOT decide race placement/reward.

---

## TrackService
**Owns:** TrackPiece registry, TrackDefinition loading, validation, building identical lanes.

```text
ValidatePieceTemplate(pieceId)
BuildTrack(definitionId, laneCount, seed?) -> TrackRuntime
DestroyTrack(trackRuntime)
GetDefinition(id)
```

Does not decide player progression.

---

## ProgressValidationService
**Owns:** ordered checkpoints, lane bounds, finish validation, suspicious movement envelope.

```text
AttachRacer(raceRuntime, racerRuntime)
Step(dt)
TryFinish(racerRuntime)
ResetRacerProgress(racerRuntime, checkpointId)
```

Produces validated progress/finish events for `RaceService`.

---

## PlayerDataService
**Owns:** canonical profile cache, DataStore key access, session lease/handoff, migrations and all persistent mutations. Exact store/key/lease/GrantId/receipt rules are `31` and `56`; no other service invents a save path.

Required public behavior includes:
```text
LoadAndAcquire(player, teleportData) -> Ready | GuestSafe
ApplyRaceGrant(player, grantId, delta) -> committedDelta | AlreadyApplied | NotWritable
ApplyEquip(player, request)
ApplySettings(player, request)
PurchaseCatalogItem(player, requestId, itemId)
ApplyPassEntitlement(player, skuKey, grantSet)
ApplyDeveloperProductReceipt(player, receiptInfo, productDef)
BeginTransfer(player, targetPlaceId) -> transferToken
HeartbeatLease(player)
ReleaseIfOwned(player)
```

`PlayerDataService` never writes a stale full profile without revalidating current store state/lease. Cross-place transfer is a lease handoff, not an assumption that `PlayerRemoving` finished first.
---

## RewardService
**Owns:** calculation/grant of gameplay rewards after server-validated result.

```text
CalculateRaceReward(result, profile) -> RaceGrantDelta
CreateGrantId(heatId, racerId) -> GrantId
Commit(player, grantId, raceGrantDelta) -> committedDelta | AlreadyApplied | NotWritable
```

`Commit` delegates persistence to `PlayerDataService:ApplyRaceGrant` (`31`). No client-provided amount/GrantId is accepted.

---

## CosmeticService
**Owns:** cosmetic definitions, ownership/equip validation, application to racer visual presentation.

```text
CanEquip(player, slot, itemId)
Equip(player, slot, itemId)
PurchaseWithCoins(player, requestId, itemId)
ApplyLoadout(racerRuntime, profile)
```

**Invariant:** cosmetic definition never changes canonical physics collider/body dimensions/motor values. Roblox avatar rider rendering is not an entitlement/equip owner and must not duplicate this service.

---

## MonetizationService
**Owns:** Roblox purchase prompt flow integration and idempotent grant routing.

Does not own economy desire/design; that lives in product docs.

```text
PromptProduct(player, offerId)
ReconcilePassEntitlement(player, skuKey)
HandleReceipt(receiptInfo)
GrantPurchasedValue(...)
```

Purchase result must be server-confirmed/idempotent. Exact Developer Product retry/grant semantics and the durable `PurchaseId` ledger live only in `56_PURCHASE_RECEIPT_GRANT_CONTRACT.md`; Coin catalog transactions and Pass reconciliation live in `71_CATALOG_TRANSACTION_AND_PASS_ENTITLEMENT_CONTRACT.md`.

---

## AnalyticsAdapter
**Owns:** one gateway to Roblox AnalyticsService event calls.

```text
LogFunnelStep(player, funnelId, stepId, fields)
LogEconomy(...)
LogCustom(player, eventName, value?, fields?)
```

Controllers/services do not call AnalyticsService directly. KPI/questions live in `10_ANALYTICS_TEST_PLAN.md`; **exact event names/fields live only in `46_ANALYTICS_EVENT_DICTIONARY.md`**.

---

# 4. Runtime stateful objects

## RaceRuntime
One instance per heat.

Owns runtime-only state:
```text
raceId
phase
trackRuntime
racers[]
startedAt
finishOrder[]
timeoutAt
```

No persistent player data stored inside beyond references/ids.

Methods conceptually:
```text
AddRacer(racerRuntime)
SetPhase(phase)
RecordFinish(racerRuntime, serverTime)
GetPlacementSnapshot()
Destroy()
```

---

## RacerRuntime
One instance per active racer.

Owns:
```text
player
model/body
laneRuntime
legPair
leftLeg/rightLeg aliases to rigid pair children
shapeVersion
checkpointTracker
finished
respawning
```

```text
ApplyShape(shapeSpec)
ApplyValidatedShape(shapeSpec)
GetLegPair()
RespawnAt(checkpoint)
SetFinished()
Destroy()
```

`ApplyShape` / `ApplyValidatedShape` stage and atomically replace one shared `LegPairAssembly`. Redraw preserves the current single axle phase and BodyCollider motion state; failed build/commit/enable restores the previous pair. `RacerRuntime` does not run a Heartbeat phase-chasing controller and does not own camera or rider rendering.

---

## BotRacerController
One stateful controller per bot racer, introduced only when Bot Fill becomes active.

Owns:
```text
racerRuntime reference
botProfile reference
reaction timer
current legal shape intent / next decision time
```

Does **not** own race phase, checkpoints, rewards, physical constants or a second movement system. It reads upcoming TrackPiece requirement tags from `TrackRuntime/TrackService`, chooses a legal shape intent from `BotConfig`, and routes that intent through the same `LegShapeService/RacerRuntime.ApplyShape` path as humans.

Conceptual methods:
```text
Start(racerRuntime, botProfile, trackRuntime)
Tick(dt)
RequestNextShape(context)
Stop()
Destroy()
```

Invariant: no teleport/rubber-band/hidden physics boost. Policy values are frozen for the heat per `40`.

---

## LegPairAssembly
One per currently accepted racer shape. This is the R17 mechanical owner for the rotating pair.

Owns actual Instances/state:
```text
AxleRoot
AxleJoint (single HingeConstraint)
one motor configuration
leftLeg/rightLeg rigid LegAssembly children
single current axle phase
```

Conceptual/runtime contract:
```text
new(racerModel, shapeSpec, motorEnabled?, initialPhaseDegrees?, staged?)
GetRoot()
GetJoint()
GetLeftLeg()
GetRightLeg()
GetPhaseDegrees()
Commit()
SetEnabled(bool)
SetRetiring(bool)
Destroy()
```

Invariants:
- exactly one `AxleJoint` motor drives both sides;
- both side shapes use the same authoritative ShapeSpec and locomotion direction;
- right side is mounted at `RightPhaseOffsetDegrees = 180` relative to left, structurally, not by continuous velocity correction;
- side sockets use the canonical `LegSocketZAbs` surface offset;
- redraw swaps the whole pair atomically and preserves one axle phase;
- no second hidden hinge/motor may be introduced in a side `LegAssembly`.

---

## LegAssembly
One per rigid visual/physical side of a `LegPairAssembly`.

Owns actual side Instances:
```text
LegRoot
segments[]
visuals[]
model
socket mount / fixed phase transform relative to AxleRoot
```

Conceptual/runtime contract:
```text
new(racerModel, side, shapeSpec, axleRoot, socketZ, phaseDegrees, staged?)
GetRoot()
GetMappedPoints()
GetSegments()
GetModel()
Commit()
SetRetiring(bool)
Destroy()
```

`LegAssembly` owns **no HingeConstraint and no motor**. Its physical segments are rigidly welded to its `LegRoot`; the `LegRoot` is rigidly mounted to the pair's `AxleRoot`. Presentation geometry remains non-colliding/non-touching/non-querying/massless. The pair, not either side, owns rotation and motor lifetime.

---

## TrackRuntime
One per active heat.

Owns built models, lanes, checkpoint descriptors, finish marker.

```text
GetLane(index)
GetCheckpointList(laneIndex)
GetFinish(laneIndex)
Destroy()
```

---

## CheckpointTracker
Small stateful object per racer.

```text
nextIndex
lastSafeCheckpoint
lastProgressTime
```

Does not inspect remotes or grant rewards.

---

# 5. Pure shared modules

## StrokeMath
Pure deterministic functions only:
```text
Dedupe(points)
Clamp(points, bounds)
SimplifyRDP(points, epsilon)
Resample(points, target)
Normalize(points)
MeasureLength(points)
ComputeBounds(points)
```

No Instances, no remotes, no player state.

## GeometryMath
Transforms `ShapeSpec` into segment transforms/sizes; no world ownership.

## CameraMath
Active under the R17 M0 reference-core override. Pure deterministic helpers for frame-rate-independent camera smoothing, vertical dead-zone response and orbit/return math. No Instances, no UserInputService, no remotes and no racer authority. R17.9 allows full 360° yaw target while keeping pitch bounded and rendered motion smoothed. D09 later extends/accepts this same owner for rival/multiplayer readability rather than introducing a second camera system.

## TrackMath
Authoring/validation math for Start→End placement, clearance and topology checks.

Pure modules are the easiest place for automated tests.

---

# 6. Client controllers

## InputController
Normalizes mouse/touch lifecycle into project-level pointer events. Does not know physics. Its current drawing-pointer contract is not expanded into a general camera manager.

## DrawingController
Owns DrawCanvas interaction and local stroke preview.

Flow:
`InputController → local stroke → StrokeMath pre-clean → SubmitStroke → await StrokeResult`.

Old active leg remains during drawing.

## RaceCameraController
Active M0/R17 production presentation owner. Scriptable camera reads replicated Local Racer position and race state and owns smoothed follow/look-ahead, vertical dead-zone response, full-yaw RMB/touch world-orbit target state and automatic return to canonical side framing. The rendered orbit is smoothed; pitch remains bounded. It derives orientation from camera policy, never from BodyCollider rotation, never authors gameplay state, and never sends camera-orientation remotes. Exact starting values live in `16`; input priority lives in `59/68`. D09 is the later 2-player/rival/readability extension and acceptance of this same owner. Spectator target policy remains `74`.

## RiderPresentationController
**Active provisional M0/R17 presentation owner by Product Owner override.** E03 is the later 8-player/readability extension and acceptance task; it is no longer the first introduction of this controller.

Owns one human rider's local visual lifecycle: Player identity → server-authored racer `OwnerUserId` lookup → standardized normalized mini-avatar visual → deterministic jockey/frog-rider pose → cleanup. It may render under `Workspace.Runtime.RacePresentation` and may read player appearance, but it has no gameplay authority.

It does **not** own:
- physical BodyCollider/LegPairAssembly/LegAssembly or movement;
- camera targeting;
- checkpoint/finish state;
- Draw Racers cosmetic ownership/equip;
- server Player→RacerRuntime mapping.

Any rider BaseParts are presentation-only and obey the R17 presentation contract: non-colliding, non-touching, non-querying and massless. Human pose/readability acceptance remains Studio evidence, not CI evidence.

## HUDController
Placement/progress/countdown/redraw hint. No authoritative race logic.

## ResultsController
Displays result/podium and requeue affordance. `RequestRequeue` is a request only.

## GarageController
M2+. UI for catalog browse/preview, Coin purchase intent and owned cosmetics/loadout. Server validates actual purchase/equip via `71`.

## StoreController
M4. Owns contextual paid-offer presentation and platform prompt initiation after `OfferResult`; never grants entitlement.

## SettingsController
M2. Owns presentation settings UI/local application and validated persistence request.

## AudioController
M2. Resolves semantic audio/music keys from `47/70`; no gameplay authority.

## FeedbackController
M2. Resolves semantic VFX/haptic feedback from `47/69`; respects Reduce Motion and never decides gameplay.

---

# 7. Ownership matrix

| State | Owner |
|---|---|
| Raw pointer path before submit | local DrawingController |
| Accepted normalized ShapeSpec | server LegShapeService |
| Shared axle / motor / structural left-right phase | server LegPairAssembly |
| Side collider + visible leg geometry | server LegAssembly under LegPairAssembly |
| Physical racer | server authority / server authoritative simulation |
| Race phase | RaceService/RaceRuntime |
| Placement | RaceRuntime after ProgressValidation |
| Place routing / FTUE redirect | PlaceRouterService |
| Coins | PlayerDataService + RewardService mutation |
| Cosmetic ownership | PlayerDataService |
| Equipped cosmetic | PlayerDataService/CosmeticService |
| Camera | local RaceCameraController |
| Human rider visual lifecycle | local RiderPresentationController |
| Local UI | local HUD/Results/Garage/Store/Settings controllers |
| Audio/VFX/haptic presentation | local AudioController/FeedbackController |
| Track definition | TrackService |
| Analytics transmission | server AnalyticsAdapter |

Если два сервиса претендуют на один и тот же authoritative state — архитектура требует пересмотра.

---

# 8. Dependency graph

```text
                    RaceService
                 /      |       \
          TrackService  |   RewardService
                |       |         |
          TrackRuntime  |   PlayerDataService
                        |
                  RacerService
                        |
                   RacerRuntime
                        |
                 LegShapeService
                    /       \
              StrokeMath   LegPairAssembly
                                |
                           LegAssembly

ProgressValidationService → RaceRuntime/RacerRuntime observations
AnalyticsAdapter ← semantic events from services
CosmeticService → PlayerDataService + RacerRuntime visuals
MonetizationService → PlayerDataService/Reward grant path
RaceCameraController → CameraMath + replicated local-racer/race observations
RiderPresentationController → player appearance + server-authored racer OwnerUserId presentation lookup
```

Rule: orchestration may depend on lower-level domain services; low-level modules never require `RaceService` back. This graph is target dependency topology, not permission to instantiate later modules early outside explicit recorded overrides such as R17.

---

# 9. What NOT to create

Without new Decision Log do not create:
- `GameManager`;
- `MultiplayerManager`;
- `PhysicsManager`;
- a second axle/phase-sync manager beside `LegPairAssembly`;
- `SaveManager` next to `PlayerDataService`;
- second remote registry;
- client authoritative reward/economy object;
- broad `RacerPresentationManager` that overlaps `RiderPresentationController`, `CosmeticService` or `RaceCameraController`;
- separate per-obstacle script family if TrackPiece config can express it;
- one script per level.

---

# 10. Milestone introduction map

| Module | First milestone / task |
|---|---|
| StrokeMath | M0 |
| InputController | M0 |
| DrawingController | M0 |
| LegPairAssembly | M0 / R17 shared-axle override |
| LegAssembly | M0; rigid side geometry under LegPairAssembly |
| LegShapeService | M0 |
| RacerRuntime | M0 |
| RacerService | M1 / D05 |
| TrackMath/TrackService minimal | M0.5/M1 |
| RaceRuntime/RaceService | M1 |
| ProgressValidationService | M1 |
| CameraMath/RaceCameraController | M0 / R17 provisional; D09 extension/acceptance |
| RiderPresentationController | M0 / R17 provisional; E03 extension/acceptance |
| HUDController | M1 / D10 |
| ResultsController | M1 |
| GarageController/SettingsController | M2 |
| AudioController/FeedbackController | M2 |
| Coin catalog purchase path | M2 (`71`) |
| StoreController | M4 |
| Pass entitlement reconciliation | M4 (`71`) |
| PlayerDataService | M2 |
| RewardService | M2 |
| CosmeticService/Garage | M2 |
| AnalyticsAdapter baseline | M2 |
| BotRacerController | M3 / required before public cold-start release |
| MonetizationService | M4 |

Do not bootstrap later milestone modules before their feature becomes ACTIVE, except where an explicit current Decision Log records a bounded Product Owner override (currently R17 camera/rider presentation plus the R17 shared-axle mechanical override).
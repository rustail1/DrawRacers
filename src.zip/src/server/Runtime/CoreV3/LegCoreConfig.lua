--!strict

return {
	Mount = {
		SideOutset = 0.45,
		VerticalFraction = 0.0,
		RightPhaseDegrees = 180,
	},

	Geometry = {
		PhysicalThickness = 0.54,
		VisualThickness = 0.78,
		MaxSegments = 14,
		SegmentOverlapAllowance = 0.06,
	},

	Motor = {
		RotationSign = -1,
		TargetTipSpeed = 15.0,
		MinimumDriveRadius = 1.75,
		MinAngularVelocity = 1.5,
		MaxAngularVelocity = 8.0,
		Torque = 35000,
		Acceleration = 120,
	},

	Rebuild = {
		PreviewDuration = 0.10,
		HopTargetVelocity = 3.5,
		MaxHopDeltaVelocity = 5.0,
		ClearancePadding = 0.08,
		ClearanceTimeout = 0.50,
		MaxLift = 4.0,
		LiftTargetVelocity = 5.0,
	},
}

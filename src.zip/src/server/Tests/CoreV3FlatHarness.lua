--!strict

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local ServerStorage = game:GetService("ServerStorage")
local Workspace = game:GetService("Workspace")

local shared = ReplicatedStorage:WaitForChild("Shared")
local RemoteNames = require(shared:WaitForChild("Net"):WaitForChild("RemoteNames"))
local CollisionGroups = require(script.Parent.Parent.Runtime:WaitForChild("CollisionGroups"))
local RacerRuntime = require(script.Parent.Parent.Runtime:WaitForChild("RacerRuntime"))
local LegClearanceController = require(
	script.Parent.Parent.Runtime:WaitForChild("CoreV3"):WaitForChild("LegClearanceController")
)
local StrokeRemoteTransport = require(script.Parent.Parent.Services:WaitForChild("StrokeRemoteTransport"))

local CoreV3FlatHarness = {}

local TRACK_START_X = -30
local TRACK_END_X = 300
local TRACK_TOP_Y = 60
local TRACK_THICKNESS = 2
local TRACK_WIDTH = 24
local RACER_SPAWN = Vector3.new(0, TRACK_TOP_Y + 4.5, 0)
local DEBUG_SAMPLE_INTERVAL = 0.05
local FORCE_EPSILON = 1e-6
local REFERENCE_SHAPES = "ROUND,SMALL_ROUND,LONG,HOOK,ASYMMETRIC"

local started = false
local activePlayer: Player? = nil
local activeRacer: any = nil
local flatScene: Folder? = nil
local transportConnection: RBXScriptConnection? = nil
local playerAddedConnection: RBXScriptConnection? = nil
local playerRemovingConnection: RBXScriptConnection? = nil
local debugConnection: RBXScriptConnection? = nil
local debugElapsed = 0
local lastState = ""
local lastShapeVersion = -1
local lastForwardAssistActive = false

local function ensureFolder(parent: Instance, name: string): Folder
	local existing = parent:FindFirstChild(name)
	if existing ~= nil then
		assert(existing:IsA("Folder"), name .. " must be Folder")
		return existing
	end
	local folder = Instance.new("Folder")
	folder.Name = name
	folder.Parent = parent
	return folder
end

local function ensureRemote(parent: Instance, name: string): RemoteEvent
	local existing = parent:FindFirstChild(name)
	if existing ~= nil then
		assert(existing:IsA("RemoteEvent"), name .. " must be RemoteEvent")
		return existing
	end
	local remote = Instance.new("RemoteEvent")
	remote.Name = name
	remote.Parent = parent
	return remote
end

local function ensureDrawHud(player: Player)
	local playerGui = player:WaitForChild("PlayerGui")
	local existing = playerGui:FindFirstChild("DrawHUD")
	if existing ~= nil then
		assert(existing:IsA("ScreenGui"), "DrawHUD must be ScreenGui")
		return
	end

	local gui = Instance.new("ScreenGui")
	gui.Name = "DrawHUD"
	gui.ResetOnSpawn = false
	gui.IgnoreGuiInset = false
	gui.Parent = playerGui
end

local function ensureInfrastructure(): (Folder, RemoteEvent, RemoteEvent)
	CollisionGroups.ensure()

	local runtime = ensureFolder(Workspace, "Runtime")
	local racers = ensureFolder(runtime, "Racers")
	local tracks = ensureFolder(runtime, "Tracks")
	local presentation = ensureFolder(runtime, "RacePresentation")

	-- COREV3 is an isolated validation mode. Runtime leftovers must not become
	-- invisible obstacles or a second racer architecture during the flat gate.
	for _, child in tracks:GetChildren() do
		child:Destroy()
	end
	for _, child in racers:GetChildren() do
		child:Destroy()
	end
	for _, child in presentation:GetChildren() do
		child:Destroy()
	end

	local templates = ensureFolder(ServerStorage, "RacerTemplates")
	local oldTemplate = templates:FindFirstChild("RacerTemplate")
	if oldTemplate ~= nil then
		oldTemplate:Destroy()
	end

	local remotes = ensureFolder(ReplicatedStorage, "Remotes")
	local submitStroke = ensureRemote(remotes, RemoteNames.SubmitStroke)
	local strokeResult = ensureRemote(remotes, RemoteNames.StrokeResult)
	return tracks, submitStroke, strokeResult
end

local function buildFlatTrack(tracksRoot: Folder): Folder
	local scene = Instance.new("Folder")
	scene.Name = "CoreV3FlatHarness"
	scene.Parent = tracksRoot

	local track = Instance.new("Part")
	track.Name = "FlatCoreV3Track"
	track.Anchored = true
	track.CanCollide = true
	track.CanTouch = true
	track.CanQuery = true
	track.Size = Vector3.new(TRACK_END_X - TRACK_START_X, TRACK_THICKNESS, TRACK_WIDTH)
	track.Position = Vector3.new(
		(TRACK_START_X + TRACK_END_X) * 0.5,
		TRACK_TOP_Y - TRACK_THICKNESS * 0.5,
		0
	)
	track.Material = Enum.Material.SmoothPlastic
	track.Color = Color3.fromRGB(112, 118, 128)
	track.CollisionGroup = CollisionGroups.Track
	track.Parent = scene

	flatScene = scene
	return scene
end

local function addCubeVisual(racerModel: Model, body: Part)
	local visualRoot = racerModel:FindFirstChild("VisualRoot")
	assert(visualRoot ~= nil, "Core V3 racer missing VisualRoot")

	local visual = Instance.new("Part")
	visual.Name = "CoreV3CubeVisual"
	visual.Size = body.Size - Vector3.new(0.12, 0.12, 0.12)
	visual.CFrame = body.CFrame
	visual.Anchored = false
	visual.CanCollide = false
	visual.CanTouch = false
	visual.CanQuery = false
	visual.Massless = true
	visual.Material = Enum.Material.SmoothPlastic
	visual.Color = Color3.fromRGB(80, 180, 245)
	visual.CastShadow = true
	visual.Parent = visualRoot

	local weld = Instance.new("WeldConstraint")
	weld.Name = "CoreV3CubeVisualWeld"
	weld.Part0 = body
	weld.Part1 = visual
	weld.Parent = visual
end

local function countHinges(root: Instance): number
	local count = 0
	for _, descendant in root:GetDescendants() do
		if descendant:IsA("HingeConstraint") then
			count += 1
		end
	end
	return count
end

local function legPhysicsEnabled(leg: any?, shapeSpec: any?): boolean
	if leg == nil or shapeSpec == nil or type(shapeSpec.segmentPlan) ~= "table" then
		return false
	end
	local parts = leg:GetPhysicalSegments()
	if #parts == 0 then
		return false
	end

	local hasAuthoritativeCollider = false
	for index, part in parts do
		local planEntry = shapeSpec.segmentPlan[index]
		local shouldCollide = planEntry ~= nil and planEntry.canCollide == true
		if shouldCollide then
			hasAuthoritativeCollider = true
		end
		if part.CanCollide ~= shouldCollide or part.CanTouch ~= shouldCollide then
			return false
		end
	end
	return hasAuthoritativeCollider
end

local function hasHorizontalAssist(model: Model): boolean
	for _, descendant in model:GetDescendants() do
		if descendant:IsA("VectorForce") then
			if math.abs(descendant.Force.X) > FORCE_EPSILON then
				return true
			end
		elseif descendant:IsA("LinearVelocity") then
			if math.abs(descendant.VectorVelocity.X) > FORCE_EPSILON then
				return true
			end
		elseif descendant:IsA("BodyVelocity") then
			if math.abs(descendant.Velocity.X) > FORCE_EPSILON then
				return true
			end
		end
	end
	return false
end

local function clearanceRequiredLift(racer: any, core: any, tracksRoot: Folder): number
	if core == nil or core:GetState() ~= "WAIT_CLEAR" then
		return 0
	end
	local left = core:GetLeftLeg()
	local right = core:GetRightLeg()
	if left == nil or right == nil then
		return 0
	end
	local ok, result = pcall(function()
		return LegClearanceController.Evaluate(racer:GetBody(), left, right, tracksRoot)
	end)
	if not ok or type(result) ~= "table" or type(result.requiredLift) ~= "number" then
		return -1
	end
	return result.requiredLift
end

local function publishEvidence(racer: any, tracksRoot: Folder)
	local model = racer:GetModel()
	local core = racer:GetLegCore()
	local state = if core ~= nil then core:GetState() else "EMPTY"
	local motorEnabled = false
	local leftEnabled = false
	local rightEnabled = false
	local shapeSpec = racer:GetCurrentShapeSpec()

	if core ~= nil then
		local axle = core:GetSharedAxle()
		motorEnabled = axle:GetJoint().Enabled
		leftEnabled = legPhysicsEnabled(core:GetLeftLeg(), shapeSpec)
		rightEnabled = legPhysicsEnabled(core:GetRightLeg(), shapeSpec)
	end

	local forwardAssistActive = hasHorizontalAssist(model)
	model:SetAttribute("CoreV3State", state)
	model:SetAttribute("CoreV3HingeCount", countHinges(model))
	model:SetAttribute("CoreV3MotorEnabled", motorEnabled)
	model:SetAttribute("CoreV3LeftPhysicsEnabled", leftEnabled)
	model:SetAttribute("CoreV3RightPhysicsEnabled", rightEnabled)
	model:SetAttribute("CoreV3ClearanceRequiredLift", clearanceRequiredLift(racer, core, tracksRoot))
	model:SetAttribute("CoreV3RedrawCount", racer:GetShapeVersion())
	model:SetAttribute("CoreV3ForwardAssistActive", forwardAssistActive)
	model:SetAttribute("CoreV3PairAtomic", leftEnabled == rightEnabled)
	model:SetAttribute("CoreV3ReferenceShapes", REFERENCE_SHAPES)
	model:SetAttribute("CoreV3BodyX", racer:GetBody().Position.X)
	model:SetAttribute("CoreV3VelocityX", racer:GetBody().AssemblyLinearVelocity.X)

	if state ~= lastState then
		lastState = state
		print(string.format("[DrawRacers][COREV3] state=%s", state))
	end
	local shapeVersion = racer:GetShapeVersion()
	if shapeVersion ~= lastShapeVersion then
		lastShapeVersion = shapeVersion
		print(string.format("[DrawRacers][COREV3] accepted redraw count=%d", shapeVersion))
	end
	if forwardAssistActive and not lastForwardAssistActive then
		warn("[DrawRacers][COREV3] INVALID: horizontal movement assist detected")
	end
	lastForwardAssistActive = forwardAssistActive
end

local function createActiveRacer(player: Player)
	local racer = RacerRuntime.new({
		raceId = "COREV3_FLAT",
		slotIndex = 1,
		laneIndex = 1,
		isBot = false,
		trackId = "COREV3_FLAT_TRACK",
		spawnCFrame = CFrame.new(RACER_SPAWN),
		laneCenterZ = RACER_SPAWN.Z,
	})
	local model = racer:GetModel()
	local body = racer:GetBody()
	model:SetAttribute("DebugTarget", true)
	model:SetAttribute("OwnerUserId", player.UserId)
	model:SetAttribute("CameraMinFollowY", TRACK_TOP_Y - 8)
	model:SetAttribute("CoreV3Harness", true)
	model:SetAttribute("CoreV3ForwardAssistActive", false)
	model:SetAttribute("CoreV3ReferenceShapes", REFERENCE_SHAPES)
	addCubeVisual(model, body)
	activeRacer = racer
	return racer
end

local function destroyActiveRacer()
	if activeRacer ~= nil then
		activeRacer:Destroy()
		activeRacer = nil
	end
	activePlayer = nil
	lastState = ""
	lastShapeVersion = -1
	lastForwardAssistActive = false
end

local function attachPlayer(player: Player)
	if activePlayer ~= nil then
		return
	end
	activePlayer = player
	ensureDrawHud(player)
	createActiveRacer(player)
	print(string.format(
		"[DrawRacers][COREV3] player=%s flat racer ready; draw %s",
		player.Name,
		REFERENCE_SHAPES
	))
end

local function attachNextAvailablePlayer()
	if activePlayer ~= nil then
		return
	end
	local players = Players:GetPlayers()
	if #players > 0 then
		attachPlayer(players[1])
	end
end

function CoreV3FlatHarness.start()
	assert(RunService:IsStudio(), "CoreV3FlatHarness is Studio-only")
	if started then
		return
	end
	started = true

	local tracksRoot, submitStroke, strokeResult = ensureInfrastructure()
	buildFlatTrack(tracksRoot)

	transportConnection = StrokeRemoteTransport.Bind({
		submitStroke = submitStroke,
		strokeResult = strokeResult,
		resolveRacer = function(player)
			if player == activePlayer then
				return activeRacer
			end
			return nil
		end,
	})

	playerAddedConnection = Players.PlayerAdded:Connect(function(player)
		attachPlayer(player)
	end)
	playerRemovingConnection = Players.PlayerRemoving:Connect(function(player)
		if player == activePlayer then
			destroyActiveRacer()
			task.defer(attachNextAvailablePlayer)
		end
	end)

	debugConnection = RunService.Heartbeat:Connect(function(dt)
		debugElapsed += dt
		if debugElapsed < DEBUG_SAMPLE_INTERVAL then
			return
		end
		debugElapsed = 0
		if activeRacer ~= nil then
			publishEvidence(activeRacer, tracksRoot)
		end
	end)

	attachNextAvailablePlayer()
	print("[DrawRacers][COREV3] flat harness ready — one flat Track, no walls/steps/gaps/tunnels")
	print("[DrawRacers][COREV3] HUMAN PHYSICS PENDING — test ROUND, SMALL_ROUND, LONG, HOOK, ASYMMETRIC and 20 redraws")
end

function CoreV3FlatHarness.stop()
	if debugConnection ~= nil then
		debugConnection:Disconnect()
		debugConnection = nil
	end
	if transportConnection ~= nil then
		transportConnection:Disconnect()
		transportConnection = nil
	end
	if playerAddedConnection ~= nil then
		playerAddedConnection:Disconnect()
		playerAddedConnection = nil
	end
	if playerRemovingConnection ~= nil then
		playerRemovingConnection:Disconnect()
		playerRemovingConnection = nil
	end

	destroyActiveRacer()
	if flatScene ~= nil then
		flatScene:Destroy()
		flatScene = nil
	end
	debugElapsed = 0
	started = false
end

return CoreV3FlatHarness
